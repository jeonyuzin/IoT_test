#Data Format
#C02 Data0
#THL Temperature Data0, Humidity Data1, Illumintation Data2, Batery Data3

import sys
import tos
import datetime
import threading

AM_OSCILLOSCOPE=0x93


class OscilloscopeMsg(tos.Packet):
	def __init__(self,packet=None):
		tos.Packet.__init__(self,
				[('srcID', 'int',2),
				('seqNo','int',4),
				('type','int',2),
				('Data0','int',2),
				('Data1','int',4),
				('Data2','int',2),
				('Data3','int',2),
				('Data4','int',2),
				],
				packet)
if '-h' in sys.argv:
	print "Usage:", sys.argv[0],"serial@/dev/ttyUSB0:57600"
	sys.exit()


am=tos.AM()

while True:
	p=am.read()
	msg=OscilloscopeMsg(p.data)
	print p

##### THL Logic######
	if msg.type==2:
		print("id:",msg.srcID,"Count : ", msg.seqNo)
